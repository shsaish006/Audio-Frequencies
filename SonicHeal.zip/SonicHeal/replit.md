# Gamma-Theta Audio Processing System

## Overview

This is a full-stack audio processing application designed to embed gamma (20-80Hz) and theta (4-8Hz) frequencies into existing music tracks for cognitive enhancement purposes. The system provides an automated algorithm that overlays therapeutic brainwave frequencies while maintaining audio quality and listenability. The application features a React frontend with a modern UI for uploading, processing, and analyzing audio files, backed by an Express.js server that handles audio processing, frequency generation, and spectrograph visualization.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **UI Components**: Radix UI primitives with shadcn/ui component library for consistent design
- **Styling**: Tailwind CSS with custom CSS variables for theming and dark mode support
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **File Handling**: React Dropzone for drag-and-drop file uploads

### Backend Architecture
- **Runtime**: Node.js with Express.js server framework
- **Language**: TypeScript with ES modules
- **Audio Processing**: Custom AudioProcessor service using FFmpeg for audio manipulation
- **Frequency Generation**: Dedicated FrequencyGenerator service for creating sine wave overlays
- **File Upload**: Multer middleware for handling MP3 file uploads with size and type validation
- **Storage**: In-memory storage implementation with interface for future database integration

### Data Storage Solutions
- **Database**: PostgreSQL with Neon serverless driver configured
- **ORM**: Drizzle ORM for type-safe database operations and migrations
- **Schema**: Well-defined schema for audio tracks and processing jobs with comprehensive metadata tracking
- **File Storage**: Local file system for uploaded audio files and generated outputs

### Audio Processing Pipeline
- **Frequency Embedding**: Algorithmic overlay of gamma (20-80Hz) and theta (4-8Hz) frequencies
- **Stem Separation**: Optional feature for isolating different audio components
- **Quality Control**: Multiple metrics including inclusion percentage, distortion levels, and quality scores
- **Spectrograph Generation**: Visual frequency analysis using FFmpeg for before/after comparisons
- **Batch Processing**: Queue system for handling multiple tracks simultaneously

### API Architecture
- **RESTful Design**: Clean HTTP endpoints following REST conventions
- **File Upload**: Dedicated endpoint for audio file uploads with validation
- **Processing Jobs**: CRUD operations for managing audio processing tasks
- **Real-time Updates**: Query invalidation for live progress tracking
- **Error Handling**: Comprehensive error handling with structured responses

## External Dependencies

### Core Technologies
- **React Ecosystem**: React 18, TanStack Query v5, React Hook Form with Zod validation
- **UI Framework**: Radix UI primitives, shadcn/ui components, Tailwind CSS
- **Build Tools**: Vite with TypeScript, PostCSS, Autoprefixer

### Backend Services
- **Database**: Neon PostgreSQL serverless database
- **ORM**: Drizzle ORM with Drizzle Kit for migrations
- **Audio Processing**: FFmpeg for audio manipulation and spectrograph generation
- **File Handling**: Multer for multipart form uploads

### Development Tools
- **Type Safety**: TypeScript across frontend and backend with shared schema types
- **Validation**: Zod for runtime type validation and schema generation
- **Session Management**: Connect-pg-simple for PostgreSQL session storage
- **Development**: Replit-specific plugins for enhanced development experience

### Audio Processing Libraries
- **Web Audio API**: Browser-based audio analysis and manipulation
- **FFmpeg**: Server-side audio processing, format conversion, and spectrograph generation
- **Custom Frequency Generation**: Mathematical sine wave generation for therapeutic frequencies

### UI/UX Components
- **Radix UI**: Accessible component primitives for complex interactions
- **Lucide React**: Consistent icon system
- **Class Variance Authority**: Type-safe component variant management
- **Date-fns**: Date manipulation and formatting utilities