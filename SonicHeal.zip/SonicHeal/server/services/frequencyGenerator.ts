export class FrequencyGenerator {
  /**
   * Generate a sine wave at the specified frequency
   */
  generateSineWave(
    frequency: number,
    duration: number,
    sampleRate: number = 44100,
    amplitude: number = 0.5
  ): Float32Array {
    const sampleCount = Math.floor(duration * sampleRate);
    const samples = new Float32Array(sampleCount);
    
    for (let i = 0; i < sampleCount; i++) {
      const t = i / sampleRate;
      samples[i] = amplitude * Math.sin(2 * Math.PI * frequency * t);
    }
    
    return samples;
  }

  /**
   * Generate gamma frequency overlay (20-80Hz, optimized for 40Hz)
   */
  generateGammaOverlay(
    duration: number,
    frequency: number = 40,
    sampleRate: number = 44100
  ): Float32Array {
    // Validate gamma frequency range
    if (frequency < 20 || frequency > 80) {
      throw new Error("Gamma frequency must be between 20-80Hz");
    }

    // Use lower amplitude for gamma to ensure it's not easily audible
    const amplitude = 0.1;
    return this.generateSineWave(frequency, duration, sampleRate, amplitude);
  }

  /**
   * Generate theta frequency overlay (4-8Hz)
   */
  generateThetaOverlay(
    duration: number,
    frequency: number = 6,
    sampleRate: number = 44100
  ): Float32Array {
    // Validate theta frequency range
    if (frequency < 4 || frequency > 8) {
      throw new Error("Theta frequency must be between 4-8Hz");
    }

    // Use very low amplitude for theta as it's below audible range
    const amplitude = 0.05;
    return this.generateSineWave(frequency, duration, sampleRate, amplitude);
  }

  /**
   * Apply volume adjustment in dB
   */
  applyVolumeAdjustment(samples: Float32Array, volumeDb: number): Float32Array {
    const linearGain = Math.pow(10, volumeDb / 20);
    const adjustedSamples = new Float32Array(samples.length);
    
    for (let i = 0; i < samples.length; i++) {
      adjustedSamples[i] = samples[i] * linearGain;
    }
    
    return adjustedSamples;
  }

  /**
   * Mix multiple audio signals together
   */
  mixSignals(...signals: Float32Array[]): Float32Array {
    if (signals.length === 0) {
      throw new Error("At least one signal required for mixing");
    }

    const maxLength = Math.max(...signals.map(s => s.length));
    const mixed = new Float32Array(maxLength);
    
    for (let i = 0; i < maxLength; i++) {
      let sum = 0;
      for (const signal of signals) {
        if (i < signal.length) {
          sum += signal[i];
        }
      }
      // Prevent clipping by normalizing
      mixed[i] = Math.max(-1, Math.min(1, sum / signals.length));
    }
    
    return mixed;
  }

  /**
   * Generate a more complex gamma wave with harmonics for better cognitive effect
   */
  generateEnhancedGamma(
    duration: number,
    fundamentalFreq: number = 40,
    sampleRate: number = 44100
  ): Float32Array {
    const fundamental = this.generateGammaOverlay(duration, fundamentalFreq, sampleRate);
    
    // Add subtle harmonics at 80Hz (2nd harmonic)
    const harmonic2 = this.generateSineWave(fundamentalFreq * 2, duration, sampleRate, 0.05);
    
    return this.mixSignals(fundamental, harmonic2);
  }

  /**
   * Generate modulated theta for enhanced relaxation effect
   */
  generateModulatedTheta(
    duration: number,
    carrierFreq: number = 6,
    modulationFreq: number = 0.5,
    sampleRate: number = 44100
  ): Float32Array {
    const sampleCount = Math.floor(duration * sampleRate);
    const samples = new Float32Array(sampleCount);
    
    for (let i = 0; i < sampleCount; i++) {
      const t = i / sampleRate;
      const modulation = 1 + 0.3 * Math.sin(2 * Math.PI * modulationFreq * t);
      samples[i] = 0.05 * modulation * Math.sin(2 * Math.PI * carrierFreq * t);
    }
    
    return samples;
  }
}
