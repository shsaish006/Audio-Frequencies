import { spawn } from "child_process";
import { promises as fs } from "fs";
import path from "path";

export interface SpectrographData {
  imageBase64: string;
  frequencyBins: number[];
  timeBins: number[];
  magnitudeData: number[][];
  metadata: {
    duration: number;
    sampleRate: number;
    minFrequency: number;
    maxFrequency: number;
  };
}

export class SpectrographGenerator {
  async generateSpectrograph(audioFilePath: string): Promise<string> {
    try {
      const tempDir = path.join("temp", "spectrographs");
      await fs.mkdir(tempDir, { recursive: true });
      
      const outputImagePath = path.join(tempDir, `spectrograph_${Date.now()}.png`);
      
      // Use FFmpeg to generate spectrograph image
      await this.generateSpectrographImage(audioFilePath, outputImagePath);
      
      // Convert image to base64
      const imageBuffer = await fs.readFile(outputImagePath);
      const base64Image = imageBuffer.toString('base64');
      
      // Clean up temporary image file
      await fs.unlink(outputImagePath).catch(() => {});
      
      return `data:image/png;base64,${base64Image}`;
    } catch (error) {
      throw new Error(`Spectrograph generation failed: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  private async generateSpectrographImage(inputPath: string, outputPath: string): Promise<void> {
    return new Promise((resolve, reject) => {
      const ffmpeg = spawn("ffmpeg", [
        "-i", inputPath,
        "-lavfi", [
          "showspectrumpic=s=1024x512:mode=combined:color=rainbow:scale=log",
          "drawtext=text='Frequency (Hz)':fontcolor=white:fontsize=12:x=10:y=h-25",
          "drawtext=text='Time (s)':fontcolor=white:fontsize=12:x=w-80:y=h-10"
        ].join(","),
        "-frames:v", "1",
        "-y",
        outputPath
      ]);

      ffmpeg.stderr.on('data', (data) => {
        // Log FFmpeg output for debugging
        console.log(`FFmpeg: ${data}`);
      });

      ffmpeg.on("close", (code) => {
        if (code === 0) {
          resolve();
        } else {
          reject(new Error(`FFmpeg spectrograph generation failed with code ${code}`));
        }
      });
    });
  }

  async generateComparisonSpectrograph(
    originalPath: string,
    processedPath: string
  ): Promise<{ original: string; processed: string; comparison: string }> {
    try {
      const [originalSpec, processedSpec] = await Promise.all([
        this.generateSpectrograph(originalPath),
        this.generateSpectrograph(processedPath)
      ]);

      // Generate side-by-side comparison
      const comparisonSpec = await this.createComparisonImage(originalSpec, processedSpec);

      return {
        original: originalSpec,
        processed: processedSpec,
        comparison: comparisonSpec
      };
    } catch (error) {
      throw new Error(`Comparison spectrograph generation failed: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  private async createComparisonImage(originalBase64: string, processedBase64: string): Promise<string> {
    // This would create a side-by-side comparison image
    // For now, return the processed spectrograph
    return processedBase64;
  }

  async extractFrequencyData(audioFilePath: string): Promise<SpectrographData> {
    try {
      // Generate detailed frequency analysis data
      const frequencyData = await this.analyzeFrequencyContent(audioFilePath);
      const imageBase64 = await this.generateSpectrograph(audioFilePath);

      return {
        imageBase64,
        ...frequencyData
      };
    } catch (error) {
      throw new Error(`Frequency data extraction failed: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  private async analyzeFrequencyContent(filePath: string): Promise<Omit<SpectrographData, 'imageBase64'>> {
    return new Promise((resolve, reject) => {
      const ffmpeg = spawn("ffmpeg", [
        "-i", filePath,
        "-af", "aformat=channel_layouts=mono,showfreqs=mode=line:fscale=log:win_size=2048",
        "-f", "null",
        "-"
      ]);

      let output = "";
      ffmpeg.stderr.on('data', (data) => {
        output += data.toString();
      });

      ffmpeg.on("close", (code) => {
        try {
          // Parse FFmpeg frequency analysis output
          // This is simplified - in reality would parse the actual frequency data
          const duration = this.extractDuration(output);
          
          // Generate mock frequency bins and data for demonstration
          const frequencyBins = Array.from({ length: 512 }, (_, i) => 
            20 * Math.pow(2, (i / 512) * Math.log2(1000)) // Log scale from 20Hz to 20kHz
          );
          
          const timeBins = Array.from({ length: 100 }, (_, i) => 
            (i / 100) * duration
          );
          
          const magnitudeData = Array.from({ length: timeBins.length }, () =>
            Array.from({ length: frequencyBins.length }, () => Math.random() * 100)
          );

          resolve({
            frequencyBins,
            timeBins,
            magnitudeData,
            metadata: {
              duration,
              sampleRate: 44100,
              minFrequency: 20,
              maxFrequency: 20000
            }
          });
        } catch (error) {
          reject(error);
        }
      });
    });
  }

  private extractDuration(ffmpegOutput: string): number {
    const durationMatch = ffmpegOutput.match(/Duration: (\d{2}):(\d{2}):(\d{2}\.\d{2})/);
    if (durationMatch) {
      const [, hours, minutes, seconds] = durationMatch;
      return parseInt(hours) * 3600 + parseInt(minutes) * 60 + parseFloat(seconds);
    }
    return 180; // Default 3 minutes if not found
  }
}
