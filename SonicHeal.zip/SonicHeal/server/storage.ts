import { type AudioTrack, type InsertAudioTrack, type ProcessingJob, type InsertProcessingJob, type UpdateProcessingJob } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Audio tracks
  createAudioTrack(track: InsertAudioTrack): Promise<AudioTrack>;
  getAudioTrack(id: string): Promise<AudioTrack | undefined>;
  getAllAudioTracks(): Promise<AudioTrack[]>;
  deleteAudioTrack(id: string): Promise<boolean>;

  // Processing jobs
  createProcessingJob(job: InsertProcessingJob): Promise<ProcessingJob>;
  getProcessingJob(id: string): Promise<ProcessingJob | undefined>;
  getProcessingJobsByTrack(trackId: string): Promise<ProcessingJob[]>;
  getAllProcessingJobs(): Promise<ProcessingJob[]>;
  updateProcessingJob(id: string, updates: UpdateProcessingJob): Promise<ProcessingJob | undefined>;
  deleteProcessingJob(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private audioTracks: Map<string, AudioTrack> = new Map();
  private processingJobs: Map<string, ProcessingJob> = new Map();

  async createAudioTrack(insertTrack: InsertAudioTrack): Promise<AudioTrack> {
    const id = randomUUID();
    const track: AudioTrack = {
      ...insertTrack,
      id,
      title: insertTrack.title || null,
      artist: insertTrack.artist || null,
      genre: insertTrack.genre || null,
      createdAt: new Date(),
    };
    this.audioTracks.set(id, track);
    return track;
  }

  async getAudioTrack(id: string): Promise<AudioTrack | undefined> {
    return this.audioTracks.get(id);
  }

  async getAllAudioTracks(): Promise<AudioTrack[]> {
    return Array.from(this.audioTracks.values()).sort(
      (a, b) => b.createdAt.getTime() - a.createdAt.getTime()
    );
  }

  async deleteAudioTrack(id: string): Promise<boolean> {
    return this.audioTracks.delete(id);
  }

  async createProcessingJob(insertJob: InsertProcessingJob): Promise<ProcessingJob> {
    const id = randomUUID();
    const job: ProcessingJob = {
      ...insertJob,
      id,
      progress: insertJob.progress || 0,
      status: insertJob.status || "queued",
      gammaFrequency: insertJob.gammaFrequency || 40,
      thetaFrequency: insertJob.thetaFrequency || 6,
      overlayVolume: insertJob.overlayVolume || -3.5,
      enableStemSeparation: insertJob.enableStemSeparation || true,
      generateSpectrographs: insertJob.generateSpectrographs || true,
      highQualityMode: insertJob.highQualityMode || false,
      processingSpeed: insertJob.processingSpeed || null,
      gammaInclusion: insertJob.gammaInclusion || null,
      thetaInclusion: insertJob.thetaInclusion || null,
      qualityScore: insertJob.qualityScore || null,
      distortionLevel: insertJob.distortionLevel || null,
      frequencyMasking: insertJob.frequencyMasking || null,
      overallRating: insertJob.overallRating || null,
      outputFilename: insertJob.outputFilename || null,
      spectrographBefore: insertJob.spectrographBefore || null,
      spectrographAfter: insertJob.spectrographAfter || null,
      processingLog: insertJob.processingLog || null,
      createdAt: new Date(),
      completedAt: null,
    };
    this.processingJobs.set(id, job);
    return job;
  }

  async getProcessingJob(id: string): Promise<ProcessingJob | undefined> {
    return this.processingJobs.get(id);
  }

  async getProcessingJobsByTrack(trackId: string): Promise<ProcessingJob[]> {
    return Array.from(this.processingJobs.values()).filter(job => job.trackId === trackId);
  }

  async getAllProcessingJobs(): Promise<ProcessingJob[]> {
    return Array.from(this.processingJobs.values()).sort(
      (a, b) => b.createdAt.getTime() - a.createdAt.getTime()
    );
  }

  async updateProcessingJob(id: string, updates: UpdateProcessingJob): Promise<ProcessingJob | undefined> {
    const job = this.processingJobs.get(id);
    if (!job) return undefined;

    const updatedJob: ProcessingJob = {
      ...job,
      ...updates,
      ...(updates.status === "completed" && !job.completedAt ? { completedAt: new Date() } : {}),
    };

    this.processingJobs.set(id, updatedJob);
    return updatedJob;
  }

  async deleteProcessingJob(id: string): Promise<boolean> {
    return this.processingJobs.delete(id);
  }
}

export const storage = new MemStorage();
