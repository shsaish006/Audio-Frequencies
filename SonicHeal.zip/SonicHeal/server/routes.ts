import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertAudioTrackSchema, insertProcessingJobSchema, updateProcessingJobSchema, processingParametersSchema } from "@shared/schema";
import multer from "multer";
import path from "path";
import fs from "fs/promises";
import { AudioProcessor } from "./services/audioProcessor";
import { SpectrographGenerator } from "./services/spectrographGenerator";

const upload = multer({
  dest: "uploads/",
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB limit
  fileFilter: (req, file, cb) => {
    if (file.mimetype === "audio/mpeg" || file.mimetype === "audio/mp3") {
      cb(null, true);
    } else {
      cb(new Error("Only MP3 files are allowed"));
    }
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  const audioProcessor = new AudioProcessor();
  const spectrographGenerator = new SpectrographGenerator();

  // Upload audio file
  app.post("/api/tracks/upload", upload.single("audio"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No audio file provided" });
      }

      const { originalname, filename, size } = req.file;
      const duration = await audioProcessor.getAudioDuration(req.file.path);

      // Extract metadata from filename or use defaults
      const [title, artist] = originalname.replace(".mp3", "").split(" - ");

      const trackData = {
        filename,
        originalName: originalname,
        title: title || originalname.replace(".mp3", ""),
        artist: artist || "Unknown Artist",
        genre: req.body.genre || "Unknown",
        duration,
        fileSize: size,
      };

      const validatedData = insertAudioTrackSchema.parse(trackData);
      const track = await storage.createAudioTrack(validatedData);

      res.json({ track });
    } catch (error) {
      console.error("Upload error:", error);
      res.status(500).json({ error: "Failed to upload audio file" });
    }
  });

  // Get all tracks
  app.get("/api/tracks", async (req, res) => {
    try {
      const tracks = await storage.getAllAudioTracks();
      res.json({ tracks });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch tracks" });
    }
  });

  // Get track by ID
  app.get("/api/tracks/:id", async (req, res) => {
    try {
      const track = await storage.getAudioTrack(req.params.id);
      if (!track) {
        return res.status(404).json({ error: "Track not found" });
      }
      res.json({ track });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch track" });
    }
  });

  // Create processing job
  app.post("/api/tracks/:trackId/process", async (req, res) => {
    try {
      const track = await storage.getAudioTrack(req.params.trackId);
      if (!track) {
        return res.status(404).json({ error: "Track not found" });
      }

      const parameters = processingParametersSchema.parse(req.body);
      
      const jobData = {
        trackId: track.id,
        status: "queued" as const,
        ...parameters,
      };

      const job = await storage.createProcessingJob(jobData);

      // Start processing asynchronously
      processAudioAsync(job.id, track, parameters, audioProcessor, spectrographGenerator);

      res.json({ job });
    } catch (error) {
      console.error("Processing job creation error:", error);
      res.status(500).json({ error: "Failed to create processing job" });
    }
  });

  // Get all processing jobs
  app.get("/api/processing-jobs", async (req, res) => {
    try {
      const jobs = await storage.getAllProcessingJobs();
      res.json({ jobs });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch processing jobs" });
    }
  });

  // Get processing job by ID
  app.get("/api/processing-jobs/:id", async (req, res) => {
    try {
      const job = await storage.getProcessingJob(req.params.id);
      if (!job) {
        return res.status(404).json({ error: "Processing job not found" });
      }
      res.json({ job });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch processing job" });
    }
  });

  // Download processed audio
  app.get("/api/processing-jobs/:id/download", async (req, res) => {
    try {
      const job = await storage.getProcessingJob(req.params.id);
      if (!job || job.status !== "completed" || !job.outputFilename) {
        return res.status(404).json({ error: "Processed audio not available" });
      }

      const filePath = path.join("processed", job.outputFilename);
      res.download(filePath);
    } catch (error) {
      res.status(500).json({ error: "Failed to download processed audio" });
    }
  });

  // Get spectrographs
  app.get("/api/processing-jobs/:id/spectrographs", async (req, res) => {
    try {
      const job = await storage.getProcessingJob(req.params.id);
      if (!job) {
        return res.status(404).json({ error: "Processing job not found" });
      }

      res.json({
        before: job.spectrographBefore,
        after: job.spectrographAfter,
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch spectrographs" });
    }
  });

  // Batch process multiple tracks
  app.post("/api/tracks/batch-process", async (req, res) => {
    try {
      const { trackIds, parameters } = req.body;
      const validatedParams = processingParametersSchema.parse(parameters);
      
      const jobs = [];
      for (const trackId of trackIds) {
        const track = await storage.getAudioTrack(trackId);
        if (!track) continue;

        const jobData = {
          trackId,
          status: "queued" as const,
          ...validatedParams,
        };

        const job = await storage.createProcessingJob(jobData);
        jobs.push(job);

        // Start processing asynchronously
        processAudioAsync(job.id, track, validatedParams, audioProcessor, spectrographGenerator);
      }

      res.json({ jobs });
    } catch (error) {
      res.status(500).json({ error: "Failed to create batch processing jobs" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Async processing function
async function processAudioAsync(
  jobId: string,
  track: any,
  parameters: any,
  audioProcessor: AudioProcessor,
  spectrographGenerator: SpectrographGenerator
) {
  try {
    // Update status to processing
    await storage.updateProcessingJob(jobId, {
      status: "processing",
      progress: 0,
    });

    const inputPath = path.join("uploads", track.filename);
    const outputPath = path.join("processed", `processed_${track.filename}`);

    // Ensure processed directory exists
    await fs.mkdir("processed", { recursive: true });

    // Generate spectrograph before processing
    const spectrographBefore = await spectrographGenerator.generateSpectrograph(inputPath);

    // Update progress
    await storage.updateProcessingJob(jobId, { progress: 25 });

    // Process audio with gamma and theta frequencies
    const processingResult = await audioProcessor.processAudio(inputPath, outputPath, parameters);

    // Update progress
    await storage.updateProcessingJob(jobId, { progress: 75 });

    // Generate spectrograph after processing
    const spectrographAfter = await spectrographGenerator.generateSpectrograph(outputPath);

    // Update job with completion data
    await storage.updateProcessingJob(jobId, {
      status: "completed",
      progress: 100,
      outputFilename: `processed_${track.filename}`,
      spectrographBefore,
      spectrographAfter,
      ...processingResult.metrics,
    });

  } catch (error) {
    console.error("Processing error:", error);
    await storage.updateProcessingJob(jobId, {
      status: "failed",
      processingLog: { error: error instanceof Error ? error.message : String(error) },
    });
  }
}
