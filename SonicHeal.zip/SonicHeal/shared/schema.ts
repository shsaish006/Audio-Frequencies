import { sql } from "drizzle-orm";
import { pgTable, text, varchar, real, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const audioTracks = pgTable("audio_tracks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  filename: text("filename").notNull(),
  originalName: text("original_name").notNull(),
  artist: text("artist"),
  title: text("title"),
  genre: text("genre"),
  duration: real("duration").notNull(), // in seconds
  fileSize: integer("file_size").notNull(), // in bytes
  createdAt: timestamp("created_at").default(sql`now()`).notNull(),
});

export const processingJobs = pgTable("processing_jobs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  trackId: varchar("track_id").references(() => audioTracks.id).notNull(),
  status: text("status").notNull().default("queued"), // queued, processing, completed, failed
  progress: real("progress").default(0).notNull(), // 0-100
  gammaFrequency: real("gamma_frequency").default(40).notNull(),
  thetaFrequency: real("theta_frequency").default(6).notNull(),
  overlayVolume: real("overlay_volume").default(-3.5).notNull(),
  enableStemSeparation: boolean("enable_stem_separation").default(true).notNull(),
  generateSpectrographs: boolean("generate_spectrographs").default(true).notNull(),
  highQualityMode: boolean("high_quality_mode").default(false).notNull(),
  processingSpeed: real("processing_speed"), // multiplier of realtime
  gammaInclusion: real("gamma_inclusion"), // percentage
  thetaInclusion: real("theta_inclusion"), // percentage
  qualityScore: real("quality_score"), // 0-10
  distortionLevel: text("distortion_level"), // low, medium, high
  frequencyMasking: text("frequency_masking"), // poor, fair, good, excellent
  overallRating: integer("overall_rating"), // 1-5 stars
  outputFilename: text("output_filename"),
  spectrographBefore: text("spectrograph_before"),
  spectrographAfter: text("spectrograph_after"),
  processingLog: jsonb("processing_log"),
  createdAt: timestamp("created_at").default(sql`now()`).notNull(),
  completedAt: timestamp("completed_at"),
});

export const insertAudioTrackSchema = createInsertSchema(audioTracks).omit({
  id: true,
  createdAt: true,
});

export const insertProcessingJobSchema = createInsertSchema(processingJobs).omit({
  id: true,
  createdAt: true,
  completedAt: true,
});

export const updateProcessingJobSchema = insertProcessingJobSchema.partial();

export type InsertAudioTrack = z.infer<typeof insertAudioTrackSchema>;
export type AudioTrack = typeof audioTracks.$inferSelect;
export type InsertProcessingJob = z.infer<typeof insertProcessingJobSchema>;
export type UpdateProcessingJob = z.infer<typeof updateProcessingJobSchema>;
export type ProcessingJob = typeof processingJobs.$inferSelect;

// Processing parameters schema for API requests
export const processingParametersSchema = z.object({
  gammaFrequency: z.number().min(20).max(80).default(40),
  thetaFrequency: z.number().min(4).max(8).default(6),
  overlayVolume: z.number().min(-5).max(-2).default(-3.5),
  enableStemSeparation: z.boolean().default(true),
  generateSpectrographs: z.boolean().default(true),
  highQualityMode: z.boolean().default(false),
});

export type ProcessingParameters = z.infer<typeof processingParametersSchema>;
