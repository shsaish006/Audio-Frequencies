import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { ProcessingParameters } from "@shared/schema";

interface ProcessingParametersProps {
  parameters: ProcessingParameters;
  onParametersChange: (parameters: ProcessingParameters) => void;
}

export default function ProcessingParametersComponent({ 
  parameters, 
  onParametersChange 
}: ProcessingParametersProps) {
  
  const updateParameter = (key: keyof ProcessingParameters, value: any) => {
    onParametersChange({
      ...parameters,
      [key]: value,
    });
  };

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold flex items-center">
        <i className="fas fa-sliders-h mr-2 text-primary"></i>
        Processing Parameters
      </h3>
      
      <Card>
        <CardContent className="p-4 space-y-6">
          {/* Gamma Frequency Controls */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <Label className="font-medium flex items-center">
                <i className="fas fa-wave-square mr-2 text-chart-1"></i>
                Gamma Frequency
              </Label>
              <span 
                className="text-sm bg-secondary px-2 py-1 rounded font-mono"
                data-testid="text-gamma-frequency"
              >
                {parameters.gammaFrequency.toFixed(1)} Hz
              </span>
            </div>
            <div className="space-y-2">
              <input 
                type="range" 
                min="20" 
                max="80" 
                value={parameters.gammaFrequency}
                onChange={(e) => updateParameter('gammaFrequency', parseFloat(e.target.value))}
                className="w-full h-2 bg-muted rounded-lg appearance-none cursor-pointer"
                data-testid="slider-gamma-frequency"
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>20Hz</span>
                <span className="text-primary">40Hz (Optimal)</span>
                <span>80Hz</span>
              </div>
            </div>
          </div>
          
          {/* Theta Frequency Controls */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <Label className="font-medium flex items-center">
                <i className="fas fa-water mr-2 text-chart-2"></i>
                Theta Frequency
              </Label>
              <span 
                className="text-sm bg-secondary px-2 py-1 rounded font-mono"
                data-testid="text-theta-frequency"
              >
                {parameters.thetaFrequency.toFixed(1)} Hz
              </span>
            </div>
            <div className="space-y-2">
              <input 
                type="range" 
                min="4" 
                max="8" 
                value={parameters.thetaFrequency}
                onChange={(e) => updateParameter('thetaFrequency', parseFloat(e.target.value))}
                step="0.1" 
                className="w-full h-2 bg-muted rounded-lg appearance-none cursor-pointer"
                data-testid="slider-theta-frequency"
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>4Hz</span>
                <span>8Hz</span>
              </div>
            </div>
          </div>
          
          {/* Volume Controls */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <Label className="font-medium flex items-center">
                <i className="fas fa-volume-down mr-2 text-chart-3"></i>
                Overlay Volume
              </Label>
              <span 
                className="text-sm bg-secondary px-2 py-1 rounded font-mono"
                data-testid="text-overlay-volume"
              >
                {parameters.overlayVolume.toFixed(1)} dB
              </span>
            </div>
            <div className="space-y-2">
              <input 
                type="range" 
                min="-5" 
                max="-2" 
                value={parameters.overlayVolume}
                onChange={(e) => updateParameter('overlayVolume', parseFloat(e.target.value))}
                step="0.1" 
                className="w-full h-2 bg-muted rounded-lg appearance-none cursor-pointer"
                data-testid="slider-overlay-volume"
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>-5dB</span>
                <span>-2dB</span>
              </div>
            </div>
          </div>
          
          {/* Processing Options */}
          <div className="border-t border-border pt-4">
            <h5 className="font-medium mb-3">Processing Options</h5>
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="stem-separation"
                  checked={parameters.enableStemSeparation}
                  onCheckedChange={(checked) => updateParameter('enableStemSeparation', checked)}
                  data-testid="checkbox-stem-separation"
                />
                <Label htmlFor="stem-separation" className="text-sm">
                  Enable stem separation analysis
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="generate-spectrographs"
                  checked={parameters.generateSpectrographs}
                  onCheckedChange={(checked) => updateParameter('generateSpectrographs', checked)}
                  data-testid="checkbox-generate-spectrographs"
                />
                <Label htmlFor="generate-spectrographs" className="text-sm">
                  Generate spectrographs
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="high-quality"
                  checked={parameters.highQualityMode}
                  onCheckedChange={(checked) => updateParameter('highQualityMode', checked)}
                  data-testid="checkbox-high-quality"
                />
                <Label htmlFor="high-quality" className="text-sm">
                  High quality mode (slower)
                </Label>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
