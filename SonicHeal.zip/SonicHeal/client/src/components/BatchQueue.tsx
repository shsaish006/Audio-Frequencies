import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { ProcessingParameters } from "@shared/schema";

interface BatchQueueProps {
  processingParameters: ProcessingParameters;
}

export default function BatchQueue({ processingParameters }: BatchQueueProps) {
  const [selectedTracks, setSelectedTracks] = useState<string[]>([]);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: tracksData } = useQuery({
    queryKey: ["/api/tracks"],
  });

  const { data: jobsData } = useQuery({
    queryKey: ["/api/processing-jobs"],
  });

  const batchProcessMutation = useMutation({
    mutationFn: async (trackIds: string[]) => {
      const response = await apiRequest("POST", "/api/tracks/batch-process", {
        trackIds,
        parameters: processingParameters,
      });
      return await response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Batch Processing Started",
        description: `Started processing ${data.jobs.length} tracks.`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/processing-jobs"] });
    },
    onError: (error) => {
      toast({
        title: "Batch Processing Failed",
        description: error.message || "Failed to start batch processing.",
        variant: "destructive",
      });
    },
  });

  const tracks = tracksData?.tracks || [];
  const jobs = jobsData?.jobs || [];

  const getTrackJob = (trackId: string) => {
    return jobs.find((job: any) => job.trackId === trackId);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge className="bg-chart-4 text-background">Completed</Badge>;
      case "processing":
        return <Badge className="bg-primary text-primary-foreground">Processing</Badge>;
      case "failed":
        return <Badge className="bg-destructive text-destructive-foreground">Failed</Badge>;
      default:
        return <Badge variant="outline">Queued</Badge>;
    }
  };

  const getGenreColor = (genre: string) => {
    const colors: Record<string, string> = {
      Jazz: "bg-chart-1",
      Pop: "bg-chart-2",
      Rock: "bg-chart-3",
      Soundscape: "bg-chart-4",
      Classical: "bg-chart-5",
      "Hip Hop": "bg-accent",
      Country: "bg-primary",
      EDM: "bg-destructive",
    };
    return colors[genre] || "bg-muted";
  };

  const handleBatchProcess = () => {
    const tracksToProcess = selectedTracks.length > 0 ? selectedTracks : tracks.map((t: any) => t.id);
    batchProcessMutation.mutate(tracksToProcess);
  };

  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${minutes}:${secs.toString().padStart(2, "0")}`;
  };

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold flex items-center">
            <i className="fas fa-list mr-2 text-primary"></i>
            Batch Processing Queue
          </h3>
          <Button
            className="bg-primary text-primary-foreground hover:bg-primary/90"
            onClick={handleBatchProcess}
            disabled={batchProcessMutation.isPending || tracks.length === 0}
            data-testid="button-process-all"
          >
            <i className={`mr-2 ${batchProcessMutation.isPending ? "fas fa-spinner animate-spin" : "fas fa-play"}`}></i>
            {batchProcessMutation.isPending ? "Processing..." : "Process All"}
          </Button>
        </div>
        
        {tracks.length === 0 ? (
          <div className="text-center text-muted-foreground py-8">
            <i className="fas fa-upload text-4xl mb-4 block"></i>
            <p>Upload audio tracks to start batch processing</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-4 font-medium">Track</th>
                  <th className="text-left py-3 px-4 font-medium">Genre</th>
                  <th className="text-left py-3 px-4 font-medium">Duration</th>
                  <th className="text-left py-3 px-4 font-medium">Status</th>
                  <th className="text-left py-3 px-4 font-medium">Progress</th>
                  <th className="text-left py-3 px-4 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {tracks.map((track: any) => {
                  const job = getTrackJob(track.id);
                  return (
                    <tr key={track.id}>
                      <td className="py-3 px-4">
                        <div className="flex items-center space-x-3">
                          <div className={`w-8 h-8 ${getGenreColor(track.genre)} rounded flex items-center justify-center`}>
                            <i className="fas fa-music text-xs text-background"></i>
                          </div>
                          <div>
                            <div className="font-medium" data-testid={`text-track-title-${track.id}`}>
                              {track.title}
                            </div>
                            <div className="text-xs text-muted-foreground" data-testid={`text-track-artist-${track.id}`}>
                              {track.artist}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <Badge className={`${getGenreColor(track.genre)} text-background`}>
                          {track.genre}
                        </Badge>
                      </td>
                      <td className="py-3 px-4 font-mono" data-testid={`text-track-duration-${track.id}`}>
                        {formatDuration(track.duration)}
                      </td>
                      <td className="py-3 px-4">
                        {getStatusBadge(job?.status || "queued")}
                      </td>
                      <td className="py-3 px-4">
                        <div className="w-full max-w-24">
                          <Progress 
                            value={job?.progress || 0} 
                            className="h-2"
                          />
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center space-x-2">
                          {job?.status === "completed" ? (
                            <>
                              <Button
                                size="sm"
                                variant="ghost"
                                className="text-primary hover:text-primary/80"
                                data-testid={`button-download-${track.id}`}
                              >
                                <i className="fas fa-download"></i>
                              </Button>
                              <Button
                                size="sm"
                                variant="ghost"
                                className="text-muted-foreground hover:text-foreground"
                                data-testid={`button-view-spectrograph-${track.id}`}
                              >
                                <i className="fas fa-chart-line"></i>
                              </Button>
                            </>
                          ) : job?.status === "processing" ? (
                            <i className="fas fa-spinner animate-spin text-primary"></i>
                          ) : (
                            <Button
                              size="sm"
                              variant="ghost"
                              className="text-primary hover:text-primary/80"
                              onClick={() => batchProcessMutation.mutate([track.id])}
                              disabled={batchProcessMutation.isPending}
                              data-testid={`button-process-${track.id}`}
                            >
                              <i className="fas fa-play"></i>
                            </Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
