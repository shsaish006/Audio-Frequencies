import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { ProcessingParameters } from "@shared/schema";

interface SpectrographVisualizationProps {
  trackId: string;
  processingParameters: ProcessingParameters;
}

export default function SpectrographVisualization({ 
  trackId, 
  processingParameters 
}: SpectrographVisualizationProps) {
  const { data: jobsData } = useQuery({
    queryKey: ["/api/processing-jobs"],
  });

  // Find the latest processing job for this track
  const currentJob = jobsData?.jobs?.find((job: any) => 
    job.trackId === trackId && job.status !== "failed"
  );

  const generateSpectrographBars = (isProcessed = false) => {
    return Array.from({ length: 16 }, (_, i) => {
      const baseHeight = 20 + Math.random() * 60;
      const opacity = isProcessed ? 0.6 : 1;
      
      return (
        <div
          key={i}
          className="frequency-bar w-2 rounded-t"
          style={{ 
            height: `${baseHeight}%`,
            opacity,
            background: isProcessed 
              ? `linear-gradient(to top, hsl(191, 95%, 52%, ${opacity}), hsl(269, 95%, 68%, ${opacity}))`
              : undefined
          }}
        />
      );
    });
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <Card>
        <CardContent className="p-4">
          <h4 className="font-medium mb-3 flex items-center">
            <i className="fas fa-chart-line mr-2 text-chart-1"></i>
            Original Spectrograph
          </h4>
          <div className="spectrograph-grid bg-secondary rounded-lg h-48 p-4 relative overflow-hidden">
            <div className="absolute inset-4">
              <div className="w-full h-full relative flex items-end justify-start space-x-2">
                {generateSpectrographBars()}
              </div>
            </div>
            <div className="absolute bottom-2 left-4 text-xs text-muted-foreground">20Hz</div>
            <div className="absolute top-2 left-4 text-xs text-muted-foreground">20kHz</div>
            <div className="absolute bottom-2 right-4 text-xs text-muted-foreground">5:24</div>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardContent className="p-4">
          <h4 className="font-medium mb-3 flex items-center">
            <i className="fas fa-chart-area mr-2 text-chart-2"></i>
            Processed Spectrograph
          </h4>
          <div className={`spectrograph-grid bg-secondary rounded-lg h-48 p-4 relative overflow-hidden ${
            currentJob?.status === "processing" ? "processing-glow" : ""
          }`}>
            <div className="absolute inset-4">
              <div className="w-full h-full relative flex items-end justify-start space-x-2">
                {generateSpectrographBars(true)}
              </div>
              
              {/* Gamma frequency overlay indicator */}
              <div 
                className="absolute left-0 w-full h-1 bg-primary/80 rounded"
                style={{ bottom: "35%" }}
                data-testid="gamma-frequency-indicator"
              />
              
              {/* Theta frequency overlay indicator */}
              <div 
                className="absolute bottom-1 left-0 w-full h-0.5 bg-accent/80 rounded"
                data-testid="theta-frequency-indicator"
              />
            </div>
            
            <div className="absolute bottom-2 left-4 text-xs text-muted-foreground">20Hz</div>
            <div className="absolute top-2 left-4 text-xs text-muted-foreground">20kHz</div>
            <div className="absolute bottom-2 right-4 text-xs text-muted-foreground">5:24</div>
            <div className="absolute bottom-16 right-4 text-xs text-primary font-mono" data-testid="text-gamma-overlay">
              {processingParameters.gammaFrequency}Hz γ
            </div>
            <div className="absolute bottom-1 right-4 text-xs text-accent font-mono" data-testid="text-theta-overlay">
              {processingParameters.thetaFrequency}Hz θ
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
