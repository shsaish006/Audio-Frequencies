import { useState, useRef, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";

interface AudioPlayerProps {
  trackId: string;
}

export default function AudioPlayer({ trackId }: AudioPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(75);
  const audioRef = useRef<HTMLAudioElement>(null);

  const { data: trackData } = useQuery({
    queryKey: ["/api/tracks", trackId],
    enabled: !!trackId,
  });

  const track = trackData?.track;

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const updateTime = () => setCurrentTime(audio.currentTime);
    const updateDuration = () => setDuration(audio.duration);
    const handleEnded = () => setIsPlaying(false);

    audio.addEventListener("timeupdate", updateTime);
    audio.addEventListener("loadedmetadata", updateDuration);
    audio.addEventListener("ended", handleEnded);

    return () => {
      audio.removeEventListener("timeupdate", updateTime);
      audio.removeEventListener("loadedmetadata", updateDuration);
      audio.removeEventListener("ended", handleEnded);
    };
  }, [track]);

  const togglePlayPause = () => {
    const audio = audioRef.current;
    if (!audio) return;

    if (isPlaying) {
      audio.pause();
    } else {
      audio.play();
    }
    setIsPlaying(!isPlaying);
  };

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, "0")}`;
  };

  const generateWaveformBars = () => {
    return Array.from({ length: 50 }, (_, i) => (
      <div
        key={i}
        className="frequency-bar w-1"
        style={{ 
          height: `${20 + Math.random() * 60}%`,
          opacity: currentTime > 0 && (i / 50) <= (currentTime / duration) ? 1 : 0.3,
        }}
      />
    ));
  };

  if (!track) {
    return (
      <div className="bg-secondary rounded-lg p-4 mb-6">
        <div className="text-center text-muted-foreground">
          No track selected
        </div>
      </div>
    );
  }

  return (
    <div className="bg-secondary rounded-lg p-4 mb-6">
      <div className="flex items-center space-x-4">
        <Button
          size="lg"
          className="w-10 h-10 bg-primary text-primary-foreground rounded-full flex items-center justify-center hover:bg-primary/90 transition-colors"
          onClick={togglePlayPause}
          data-testid="button-play-pause"
        >
          <i className={`text-sm ${isPlaying ? "fas fa-pause" : "fas fa-play ml-0.5"}`}></i>
        </Button>

        <div className="flex-1">
          <div className="waveform-container h-12 rounded-md mb-2 relative overflow-hidden">
            <div className="absolute inset-0 flex items-center justify-center space-x-1 px-4">
              {generateWaveformBars()}
            </div>
          </div>
          <div className="flex justify-between text-xs text-muted-foreground">
            <span data-testid="text-current-time">{formatTime(currentTime)}</span>
            <span data-testid="text-duration">{formatTime(duration || track.duration)}</span>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <i className="fas fa-volume-up text-muted-foreground"></i>
          <Slider
            value={[volume]}
            onValueChange={(value) => {
              setVolume(value[0]);
              if (audioRef.current) {
                audioRef.current.volume = value[0] / 100;
              }
            }}
            max={100}
            step={1}
            className="w-20"
            data-testid="slider-volume"
          />
        </div>
      </div>

      <audio
        ref={audioRef}
        src={`/uploads/${track.filename}`}
        onLoadedMetadata={() => {
          if (audioRef.current) {
            setDuration(audioRef.current.duration);
            audioRef.current.volume = volume / 100;
          }
        }}
      />
    </div>
  );
}
