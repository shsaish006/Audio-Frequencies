import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export default function Header() {
  return (
    <header className="bg-card border-b border-border px-6 py-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold">Audio Processing Dashboard</h2>
          <p className="text-sm text-muted-foreground">
            Gamma (20-80Hz) & Theta (4-8Hz) Frequency Embedding
          </p>
        </div>
        <div className="flex items-center space-x-4">
          <Badge variant="secondary" className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-chart-4 rounded-full animate-pulse-slow"></div>
            <span className="text-sm font-medium" data-testid="text-system-status">System Active</span>
          </Badge>
          <Button 
            className="bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
            data-testid="button-export-results"
          >
            <i className="fas fa-download mr-2"></i>
            Export Results
          </Button>
        </div>
      </div>
    </header>
  );
}
