import { useQuery } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";

interface SidebarProps {
  currentTrackId: string | null;
}

export default function Sidebar({ currentTrackId }: SidebarProps) {
  const { data: jobsData } = useQuery({
    queryKey: ["/api/processing-jobs"],
  });

  const jobs = jobsData?.jobs || [];
  const completedJobs = jobs.filter((job: any) => job.status === "completed").length;
  const totalJobs = jobs.length;

  return (
    <aside className="w-64 bg-card border-r border-border flex flex-col">
      <div className="p-6 border-b border-border">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-gradient-to-r from-primary to-accent rounded-lg flex items-center justify-center">
            <i className="fas fa-wave-square text-primary-foreground text-sm"></i>
          </div>
          <div>
            <h1 className="text-lg font-semibold">Gamma-Theta</h1>
            <p className="text-xs text-muted-foreground">Audio Processing</p>
          </div>
        </div>
      </div>
      
      <nav className="flex-1 p-4 space-y-2">
        <a 
          href="#" 
          className="flex items-center space-x-3 px-3 py-2 rounded-md bg-primary text-primary-foreground"
          data-testid="nav-upload-process"
        >
          <i className="fas fa-upload w-4"></i>
          <span className="text-sm font-medium">Upload & Process</span>
        </a>
        <a 
          href="#" 
          className="flex items-center space-x-3 px-3 py-2 rounded-md text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors"
          data-testid="nav-batch-queue"
        >
          <i className="fas fa-list w-4"></i>
          <span className="text-sm font-medium">Batch Queue</span>
          {totalJobs > 0 && (
            <Badge variant="secondary" className="ml-auto">
              {totalJobs}
            </Badge>
          )}
        </a>
        <a 
          href="#" 
          className="flex items-center space-x-3 px-3 py-2 rounded-md text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors"
          data-testid="nav-analytics"
        >
          <i className="fas fa-chart-line w-4"></i>
          <span className="text-sm font-medium">Analytics</span>
        </a>
        <a 
          href="#" 
          className="flex items-center space-x-3 px-3 py-2 rounded-md text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors"
          data-testid="nav-settings"
        >
          <i className="fas fa-cog w-4"></i>
          <span className="text-sm font-medium">Settings</span>
        </a>
      </nav>
      
      <div className="p-4 border-t border-border">
        <div className="bg-secondary rounded-lg p-3">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-secondary-foreground">
              Processing Status
            </span>
            <span className="text-xs text-muted-foreground" data-testid="text-processing-status">
              {completedJobs}/{totalJobs > 0 ? totalJobs : 8} complete
            </span>
          </div>
          <div className="w-full bg-muted rounded-full h-2">
            <div 
              className="bg-primary h-2 rounded-full transition-all duration-500" 
              style={{ 
                width: totalJobs > 0 ? `${(completedJobs / totalJobs) * 100}%` : '25%' 
              }}
            ></div>
          </div>
        </div>
      </div>
    </aside>
  );
}
