import { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";

const REQUIRED_SONGS = [
  { title: "Take Five", artist: "Dave Brubeck Quartet", genre: "Jazz" },
  { title: "Lucky Star", artist: "Madonna", genre: "Pop" },
  { title: "Radio Ga Ga", artist: "Queen", genre: "Rock" },
  { title: "Only Time", artist: "Enya", genre: "Soundscape" },
  { title: "Morning Mood", artist: "Edvard Grieg", genre: "Classical" },
  { title: "Today Was a Good Day", artist: "Ice Cube", genre: "Hip Hop" },
  { title: "Hurricane", artist: "Luke Combs", genre: "Country" },
  { title: "Just Hold Me", artist: "Steve Aoki feat. Ryan Tedder", genre: "EDM" },
];

const GENRE_COLORS: Record<string, string> = {
  Jazz: "bg-chart-4 text-background",
  Pop: "bg-chart-2 text-background", 
  Rock: "bg-chart-1 text-background",
  Soundscape: "bg-chart-3 text-background",
  Classical: "bg-chart-5 text-background",
  "Hip Hop": "bg-accent text-accent-foreground",
  Country: "bg-primary text-primary-foreground",
  EDM: "bg-destructive text-destructive-foreground",
};

interface FileUploadProps {
  onTrackUploaded: (trackId: string) => void;
}

export default function FileUpload({ onTrackUploaded }: FileUploadProps) {
  const [uploadProgress, setUploadProgress] = useState(0);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("audio", file);
      
      // Extract genre from filename if possible
      const genre = REQUIRED_SONGS.find(song => 
        file.name.toLowerCase().includes(song.title.toLowerCase()) ||
        file.name.toLowerCase().includes(song.artist.toLowerCase())
      )?.genre || "Unknown";
      
      formData.append("genre", genre);

      const response = await apiRequest("POST", "/api/tracks/upload", formData);
      return await response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Upload Successful",
        description: `"${data.track.originalName}" has been uploaded successfully.`,
      });
      onTrackUploaded(data.track.id);
      setUploadProgress(0);
      queryClient.invalidateQueries({ queryKey: ["/api/tracks"] });
    },
    onError: (error) => {
      toast({
        title: "Upload Failed",
        description: error.message || "Failed to upload audio file.",
        variant: "destructive",
      });
      setUploadProgress(0);
    },
  });

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (!file) return;

    if (!file.type.includes("audio/mpeg") && !file.name.endsWith(".mp3")) {
      toast({
        title: "Invalid File Type",
        description: "Please upload an MP3 file.",
        variant: "destructive",
      });
      return;
    }

    if (file.size > 50 * 1024 * 1024) {
      toast({
        title: "File Too Large",
        description: "Please upload a file smaller than 50MB.",
        variant: "destructive",
      });
      return;
    }

    // Simulate upload progress
    setUploadProgress(0);
    const progressInterval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 90) {
          clearInterval(progressInterval);
          return prev;
        }
        return prev + 10;
      });
    }, 200);

    uploadMutation.mutate(file);
  }, [uploadMutation, toast]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      "audio/mpeg": [".mp3"],
    },
    maxFiles: 1,
    disabled: uploadMutation.isPending,
  });

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold flex items-center">
        <i className="fas fa-file-audio mr-2 text-primary"></i>
        Audio File Upload
      </h3>
      
      <div 
        {...getRootProps()} 
        className={`upload-zone rounded-lg p-8 text-center cursor-pointer transition-all ${
          isDragActive ? "border-primary bg-primary/5" : ""
        } ${uploadMutation.isPending ? "opacity-50 cursor-not-allowed" : ""}`}
        data-testid="upload-zone"
      >
        <input {...getInputProps()} data-testid="input-file" />
        <div className="space-y-4">
          <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mx-auto">
            <i className={`text-2xl text-muted-foreground ${
              uploadMutation.isPending ? "fas fa-spinner animate-spin" : "fas fa-cloud-upload-alt"
            }`}></i>
          </div>
          <div>
            <p className="text-lg font-medium">
              {uploadMutation.isPending ? "Uploading..." : "Drop MP3 files here"}
            </p>
            <p className="text-sm text-muted-foreground">
              {uploadMutation.isPending ? "Please wait..." : "or click to browse"}
            </p>
          </div>
          {uploadProgress > 0 && uploadProgress < 100 && (
            <div className="w-full max-w-xs mx-auto">
              <Progress value={uploadProgress} className="h-2" />
            </div>
          )}
          <div className="text-xs text-muted-foreground">
            Supported: MP3 files up to 50MB
          </div>
        </div>
      </div>
      
      {/* Required Songs */}
      <Card>
        <CardContent className="p-4">
          <h4 className="font-medium mb-3 flex items-center">
            <i className="fas fa-music mr-2 text-accent"></i>
            Required Test Songs
          </h4>
          <div className="space-y-2 text-sm">
            {REQUIRED_SONGS.slice(0, 4).map((song, index) => (
              <div 
                key={index}
                className="flex justify-between items-center py-2 border-b border-border last:border-b-0"
              >
                <span data-testid={`text-song-${index}`}>
                  {song.title} - {song.artist}
                </span>
                <Badge className={GENRE_COLORS[song.genre] || "bg-muted text-muted-foreground"}>
                  {song.genre}
                </Badge>
              </div>
            ))}
            <div className="text-xs text-muted-foreground mt-2" data-testid="text-more-songs">
              +4 more songs...
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
