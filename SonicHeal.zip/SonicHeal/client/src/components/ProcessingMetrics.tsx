import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface ProcessingMetricsProps {
  trackId: string | null;
}

export default function ProcessingMetrics({ trackId }: ProcessingMetricsProps) {
  const { data: jobsData } = useQuery({
    queryKey: ["/api/processing-jobs"],
  });

  // Find the latest processing job for the current track
  const currentJob = jobsData?.jobs?.find((job: any) => 
    trackId && job.trackId === trackId
  );

  const renderStarRating = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <i 
        key={i}
        className={`text-xs ${i < rating ? "fas fa-star text-chart-3" : "fas fa-star text-muted-foreground"}`}
      />
    ));
  };

  const getQualityBadgeColor = (level: string) => {
    switch (level) {
      case "excellent": return "bg-chart-4 text-background";
      case "good": return "bg-chart-1 text-background";
      case "fair": return "bg-chart-3 text-background";
      case "poor": return "bg-destructive text-destructive-foreground";
      default: return "bg-muted text-muted-foreground";
    }
  };

  const getDistortionColor = (level: string) => {
    switch (level) {
      case "low": return "bg-chart-4";
      case "medium": return "bg-chart-3";
      case "high": return "bg-destructive";
      default: return "bg-muted";
    }
  };

  const getDistortionWidth = (level: string) => {
    switch (level) {
      case "low": return "w-2";
      case "medium": return "w-8";
      case "high": return "w-12";
      default: return "w-4";
    }
  };

  if (!currentJob) {
    return (
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-medium">Processing Metrics</h4>
              <i className="fas fa-stopwatch text-chart-3"></i>
            </div>
            <div className="text-center text-muted-foreground py-8">
              No processing data available
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-medium">Listenability Analysis</h4>
              <i className="fas fa-ear-listen text-chart-4"></i>
            </div>
            <div className="text-center text-muted-foreground py-8">
              Upload and process a track first
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-medium">Export Options</h4>
              <i className="fas fa-download text-primary"></i>
            </div>
            <div className="space-y-3">
              <Button disabled className="w-full" variant="outline">
                <i className="fas fa-file-audio mr-2"></i>Download MP3
              </Button>
              <Button disabled className="w-full" variant="outline">
                <i className="fas fa-chart-line mr-2"></i>Export Spectrographs
              </Button>
              <Button disabled className="w-full" variant="outline">
                <i className="fas fa-file-csv mr-2"></i>Download Report
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const isCompleted = currentJob.status === "completed";

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-medium">Processing Metrics</h4>
            <i className="fas fa-stopwatch text-chart-3"></i>
          </div>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-sm text-muted-foreground">Processing Speed</span>
              <span className="text-sm font-mono" data-testid="text-processing-speed">
                {isCompleted ? `${currentJob.processingSpeed?.toFixed(1)}x realtime` : "Processing..."}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-muted-foreground">Gamma Inclusion</span>
              <span className="text-sm font-mono text-chart-1" data-testid="text-gamma-inclusion">
                {isCompleted ? `${currentJob.gammaInclusion?.toFixed(1)}%` : "Calculating..."}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-muted-foreground">Theta Inclusion</span>
              <span className="text-sm font-mono text-chart-2" data-testid="text-theta-inclusion">
                {isCompleted ? `${currentJob.thetaInclusion?.toFixed(1)}%` : "Calculating..."}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-muted-foreground">Quality Score</span>
              <span className="text-sm font-mono text-chart-4" data-testid="text-quality-score">
                {isCompleted ? `${currentJob.qualityScore?.toFixed(1)}/10` : "Analyzing..."}
              </span>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-medium">Listenability Analysis</h4>
            <i className="fas fa-ear-listen text-chart-4"></i>
          </div>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Distortion Level</span>
              <div className="flex items-center space-x-2">
                <div className="w-16 h-2 bg-muted rounded-full">
                  <div className={`h-2 rounded-full ${
                    isCompleted ? getDistortionColor(currentJob.distortionLevel) : "bg-muted"
                  } ${isCompleted ? getDistortionWidth(currentJob.distortionLevel) : "w-8"}`}></div>
                </div>
                <span className="text-xs font-mono capitalize" data-testid="text-distortion-level">
                  {isCompleted ? currentJob.distortionLevel || "Low" : "Analyzing"}
                </span>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Frequency Masking</span>
              <div className="flex items-center space-x-2">
                {isCompleted && currentJob.frequencyMasking ? (
                  <Badge className={getQualityBadgeColor(currentJob.frequencyMasking)}>
                    {currentJob.frequencyMasking}
                  </Badge>
                ) : (
                  <Badge variant="outline">Analyzing</Badge>
                )}
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Overall Rating</span>
              <div className="flex space-x-1" data-testid="overall-rating">
                {isCompleted ? 
                  renderStarRating(currentJob.overallRating || 4) : 
                  Array.from({ length: 5 }, (_, i) => (
                    <i key={i} className="fas fa-star text-muted-foreground text-xs animate-pulse" />
                  ))
                }
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-medium">Export Options</h4>
            <i className="fas fa-download text-primary"></i>
          </div>
          <div className="space-y-3">
            <Button 
              className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
              disabled={!isCompleted}
              data-testid="button-download-mp3"
            >
              <i className="fas fa-file-audio mr-2"></i>
              Download MP3
            </Button>
            <Button 
              className="w-full bg-secondary text-secondary-foreground hover:bg-secondary/90"
              disabled={!isCompleted}
              data-testid="button-export-spectrographs"
            >
              <i className="fas fa-chart-line mr-2"></i>
              Export Spectrographs
            </Button>
            <Button 
              className="w-full bg-muted text-muted-foreground hover:bg-muted/90"
              disabled={!isCompleted}
              data-testid="button-download-report"
            >
              <i className="fas fa-file-csv mr-2"></i>
              Download Report
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
