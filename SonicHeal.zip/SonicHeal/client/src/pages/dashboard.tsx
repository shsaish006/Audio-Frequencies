import { useState } from "react";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import FileUpload from "@/components/FileUpload";
import ProcessingParameters from "@/components/ProcessingParameters";
import AudioPlayer from "@/components/AudioPlayer";
import SpectrographVisualization from "@/components/SpectrographVisualization";
import ProcessingMetrics from "@/components/ProcessingMetrics";
import BatchQueue from "@/components/BatchQueue";
import { ProcessingParameters as ProcessingParametersType } from "@shared/schema";

export default function Dashboard() {
  const [currentTrackId, setCurrentTrackId] = useState<string | null>(null);
  const [processingParameters, setProcessingParameters] = useState<ProcessingParametersType>({
    gammaFrequency: 40,
    thetaFrequency: 6,
    overlayVolume: -3.5,
    enableStemSeparation: true,
    generateSpectrographs: true,
    highQualityMode: false,
  });

  return (
    <div className="min-h-screen flex bg-background text-foreground">
      <Sidebar currentTrackId={currentTrackId} />
      
      <main className="flex-1 flex flex-col">
        <Header />
        
        <div className="flex-1 p-6 space-y-6 overflow-auto">
          {/* Upload and Parameters Section */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <FileUpload onTrackUploaded={setCurrentTrackId} />
            <ProcessingParameters
              parameters={processingParameters}
              onParametersChange={setProcessingParameters}
            />
          </div>

          {/* Current Track Analysis */}
          {currentTrackId && (
            <div className="bg-card rounded-lg p-6 border border-border">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold flex items-center">
                  <i className="fas fa-chart-area mr-2 text-primary"></i>
                  Current Track Analysis
                </h3>
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-muted-foreground" data-testid="text-current-track">
                    Processing Audio Track
                  </span>
                  <div className="w-2 h-2 bg-chart-4 rounded-full animate-pulse-slow"></div>
                </div>
              </div>

              <AudioPlayer trackId={currentTrackId} />
              
              <SpectrographVisualization 
                trackId={currentTrackId}
                processingParameters={processingParameters}
              />
            </div>
          )}

          {/* Processing Metrics */}
          <ProcessingMetrics trackId={currentTrackId} />

          {/* Batch Processing Queue */}
          <BatchQueue processingParameters={processingParameters} />
        </div>
      </main>
    </div>
  );
}
