/**
 * Convert audio file to AudioBuffer for Web Audio API processing
 */
export async function fileToAudioBuffer(file: File, audioContext: AudioContext): Promise<AudioBuffer> {
  const arrayBuffer = await file.arrayBuffer();
  return await audioContext.decodeAudioData(arrayBuffer);
}

/**
 * Convert AudioBuffer to WAV blob for download
 */
export function audioBufferToWav(buffer: AudioBuffer): Blob {
  const length = buffer.length;
  const numberOfChannels = buffer.numberOfChannels;
  const sampleRate = buffer.sampleRate;
  const bytesPerSample = 2; // 16-bit
  const blockAlign = numberOfChannels * bytesPerSample;
  const byteRate = sampleRate * blockAlign;
  const dataSize = length * blockAlign;
  const bufferSize = 44 + dataSize;
  
  const arrayBuffer = new ArrayBuffer(bufferSize);
  const view = new DataView(arrayBuffer);
  
  // WAV header
  const writeString = (offset: number, string: string) => {
    for (let i = 0; i < string.length; i++) {
      view.setUint8(offset + i, string.charCodeAt(i));
    }
  };
  
  writeString(0, 'RIFF');
  view.setUint32(4, bufferSize - 8, true);
  writeString(8, 'WAVE');
  writeString(12, 'fmt ');
  view.setUint32(16, 16, true); // Subchunk1Size
  view.setUint16(20, 1, true); // AudioFormat (PCM)
  view.setUint16(22, numberOfChannels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, byteRate, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, bytesPerSample * 8, true);
  writeString(36, 'data');
  view.setUint32(40, dataSize, true);
  
  // Convert float samples to 16-bit PCM
  let offset = 44;
  for (let i = 0; i < length; i++) {
    for (let channel = 0; channel < numberOfChannels; channel++) {
      const sample = buffer.getChannelData(channel)[i];
      const intSample = Math.max(-1, Math.min(1, sample)) * 0x7FFF;
      view.setInt16(offset, intSample, true);
      offset += 2;
    }
  }
  
  return new Blob([arrayBuffer], { type: 'audio/wav' });
}

/**
 * Calculate frequency bin for a given frequency in Hz
 */
export function frequencyToBin(frequency: number, sampleRate: number, fftSize: number): number {
  return Math.round((frequency * fftSize) / sampleRate);
}

/**
 * Calculate frequency for a given bin index
 */
export function binToFrequency(bin: number, sampleRate: number, fftSize: number): number {
  return (bin * sampleRate) / fftSize;
}

/**
 * Apply windowing function to reduce spectral leakage
 */
export function applyHannWindow(samples: Float32Array): Float32Array {
  const windowed = new Float32Array(samples.length);
  const N = samples.length;
  
  for (let i = 0; i < N; i++) {
    const window = 0.5 * (1 - Math.cos((2 * Math.PI * i) / (N - 1)));
    windowed[i] = samples[i] * window;
  }
  
  return windowed;
}

/**
 * Calculate RMS (Root Mean Square) value for amplitude measurement
 */
export function calculateRMS(samples: Float32Array): number {
  let sum = 0;
  for (let i = 0; i < samples.length; i++) {
    sum += samples[i] * samples[i];
  }
  return Math.sqrt(sum / samples.length);
}

/**
 * Convert linear amplitude to decibels
 */
export function amplitudeToDecibels(amplitude: number): number {
  return 20 * Math.log10(Math.abs(amplitude));
}

/**
 * Convert decibels to linear amplitude
 */
export function decibelsToAmplitude(decibels: number): number {
  return Math.pow(10, decibels / 20);
}

/**
 * Detect the presence of a specific frequency in the spectrum
 */
export function detectFrequency(
  spectrumData: Uint8Array,
  targetFrequency: number,
  sampleRate: number,
  threshold: number = 50
): { detected: boolean; magnitude: number; bin: number } {
  const fftSize = (spectrumData.length - 1) * 2;
  const bin = frequencyToBin(targetFrequency, sampleRate, fftSize);
  const magnitude = spectrumData[bin];
  
  return {
    detected: magnitude > threshold,
    magnitude,
    bin,
  };
}

/**
 * Calculate spectral centroid (brightness measure)
 */
export function calculateSpectralCentroid(spectrumData: Uint8Array, sampleRate: number): number {
  const fftSize = (spectrumData.length - 1) * 2;
  let numerator = 0;
  let denominator = 0;
  
  for (let i = 0; i < spectrumData.length; i++) {
    const frequency = binToFrequency(i, sampleRate, fftSize);
    const magnitude = spectrumData[i];
    
    numerator += frequency * magnitude;
    denominator += magnitude;
  }
  
  return denominator > 0 ? numerator / denominator : 0;
}

/**
 * Format time in MM:SS format
 */
export function formatTime(seconds: number): string {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = Math.floor(seconds % 60);
  return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
}

/**
 * Format file size in human readable format
 */
export function formatFileSize(bytes: number): string {
  const units = ['B', 'KB', 'MB', 'GB'];
  let size = bytes;
  let unitIndex = 0;
  
  while (size >= 1024 && unitIndex < units.length - 1) {
    size /= 1024;
    unitIndex++;
  }
  
  return `${size.toFixed(1)} ${units[unitIndex]}`;
}

/**
 * Generate color for frequency visualization
 */
export function frequencyToColor(frequency: number): string {
  // Map frequency to hue (20Hz = red, 20kHz = violet)
  const minFreq = 20;
  const maxFreq = 20000;
  const normalizedFreq = Math.log(frequency / minFreq) / Math.log(maxFreq / minFreq);
  const hue = normalizedFreq * 300; // 0 to 300 degrees (red to violet)
  
  return `hsl(${hue}, 70%, 60%)`;
}
